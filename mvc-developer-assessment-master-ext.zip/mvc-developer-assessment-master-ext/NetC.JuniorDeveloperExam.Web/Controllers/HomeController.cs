﻿using NetC.JuniorDeveloperExam.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;//in the lase example
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;


namespace NetC.JuniorDeveloperExam.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            var webClient = new WebClient();
            var path = Environment.CurrentDirectory;
            var json = webClient.DownloadString(@"C:\Users\dilsh\OneDrive\Desktop\mvc-developer-assessment-master-ext\NetC.JuniorDeveloperExam.Web\App_Data\Blog-Posts.json");
            var blogs = JsonConvert.DeserializeObject<BlogPosts>(json);
            return View(blogs);
        }


        [HttpPost]
        public ActionResult Index(Comment cmt, int id)
        {
            var webClient = new WebClient();
            string filePath = @"C:\Users\dilsh\OneDrive\Desktop\mvc-developer-assessment-master-ext\NetC.JuniorDeveloperExam.Web\App_Data\Blog-Posts.json";
            StreamReader reader = new StreamReader(filePath); 
            var json = reader.ReadToEnd();
            var blogs = JsonConvert.DeserializeObject<List<BlogPosts>>(json);

            
            return View();
        }


        
    }
}